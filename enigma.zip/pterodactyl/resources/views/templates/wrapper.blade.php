<!DOCTYPE html>
<html>
    <head>
        <title>{{ config('app.name', 'ItsHost') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
            <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
            <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <link rel="shortcut icon" href="/favicons/favicon.ico">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
            <meta name="theme-color" content="#0e4688">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show
        <style>
            @import url('//fonts.googleapis.com/css?family=Rubik:300,400,500&display=swap');
            @import url('//fonts.googleapis.com/css?family=IBM+Plex+Mono|IBM+Plex+Sans:500&display=swap');
        </style>

        @yield('assets')

        @include('layouts.scripts')
    
        <style id="itshost-theme-overrides">
          :root { --itshost-orange: #ff7a00; --itshost-blue: #087cff; --itshost-white: #ffffff; --itshost-black: #111111; }
          html, body, #app, #root { background: #fff !important; color: #111 !important; }
          body, p, span, label, h1, h2, h3, h4, h5, h6, a, li, small, strong, div { color: inherit; }
          body, #app, #root, main, header, footer, nav, aside, section, article, form, .content, .container, .wrapper, .page-content { background-color: #fff !important; }
          button, [role="button"], .btn, a.btn, input[type="submit"] { background-color: var(--itshost-blue) !important; color: #fff !important; border: 2px solid var(--itshost-orange) !important; box-shadow: 3px 3px 0 var(--itshost-orange) !important; }
          a { color: var(--itshost-blue); }
          input, textarea, select, .form-control { background: #fff !important; color: #111 !important; border: 2px solid var(--itshost-orange) !important; border-radius: 2px !important; }
          .card, [class*="card"], .modal-content, .dropdown-menu, table, th, td, .form-control { background-color: #fff !important; color: #111 !important; border-color: var(--itshost-orange) !important; }
          .sidebar, [class*="sidebar"], [class*="Sidebar"], .navbar, [class*="navbar"], [class*="Navbar"] { background-color: #fff !important; color: #111 !important; border-color: var(--itshost-orange) !important; }
          .active, [aria-current="page"], [data-active="true"] { background-color: var(--itshost-blue) !important; color: #fff !important; border: 2px solid var(--itshost-orange) !important; }
          svg, svg * { accent-color: var(--itshost-blue); }
          hr { border-color: var(--itshost-orange) !important; }
        </style>
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>

